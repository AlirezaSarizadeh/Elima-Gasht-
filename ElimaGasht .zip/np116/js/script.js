

$('.menuTrigger').click(function () {
  $('.panel-menu').toggleClass('isOpen');

});

$('.openSubPanel').click(function () {
  $(this).next('.subPanel').addClass('isOpen');
});

$('.closeSubPanel').click(function () {
  $(this).closest(".subPanel").removeClass("isOpen");
});

$("#panel-menu").on("click", function (e) {
  var target = $(e.target);
  if (target.attr('id') == 'menu-toggle' || target.parents('#panel-menu').length > 0 || target.parents('.panel-menu').length > 0) {
    console.log('id: ' + target.attr('id') + 'contains: ' + $.contains(target, $('.panel-menu')));
  } else {
    if ($(".panel-menu").hasClass('isOpen'))
      $(".panel-menu").removeClass("isOpen");
    $('.subPanel').removeClass('isOpen');
  }

});

$('.closePanel').click(function () {
  $('.panel-menu').removeClass('isOpen');
  $('.subPanel').removeClass('isOpen');

});

$('.scrollup').click(function () {
  $("html,body").animate({
    scrollTop: 0
  }, 1000);
  return false;
});


if ($('.header').length) {
  $(document).ready(function () {
    $(window).scroll(function () {
      if ($(window).scrollTop() > 100) {
        $(".header").addClass("sticky-menu");
      } else {
        $(".header").removeClass("sticky-menu");
      }
    });
  });
}

new WOW().init();
if (matchMedia('only screen and (max-width: 767.99px)').matches) {
  $(".set > span").on("click", function () {
    if ($(this).hasClass('active')) {
      $(this).removeClass("active");
      $(this).siblings('.content').slideUp(200);
      $(".set > span i").removeClass("fas fa-chevron-up").addClass("fas fa-chevron-up");
    } else {
      $(".set > span i").removeClass("fas fa-chevron-up").addClass("fas fa-chevron-up");
      $(this).find("i").removeClass("fas fa-chevron-down").addClass("fas fa-chevron-up");
      $(".set > span").removeClass("active");
      $(this).addClass("active");
      $('.content').slideUp(200);
      $(this).siblings('.content').slideDown(200);
    }

  });
}

new WOW().init();
$(document).ready(function () {

  $(".select").select2({

  });

});


if ($('.owl-pro').length) {
  var heroSlider = $('.owl-pro');
  var owlCarouselTimeout = 3500;
  $('.owl-pro').owlCarousel({
    autoplay: false,
    //loop: true,
    //autoplayHoverPause: true,
    smartSpeed: 450,
    rtl: true,
    margin: 0,
    dots: false,
    margin: 15,
    lazyLoad: true,
    responsive: {
      0: {
        items: 1,
        nav: false,
        stagePadding: 30

      },
      400: {
        items: 1,
        nav: false,
        stagePadding: 80
      },

      600: {
        items: 2,
        nav: false,
        stagePadding: 30
      },
      700: {
        margin: 20,
        stagePadding: 70,
        items: 2

      },
      768: {
        items: 3,
        nav: false,

      },
      992: {
        items: 3,
        nav: true,

      },
     
      1000: {
        stagePadding: 150,
        items: 2,
        nav: true,

      } ,
      1250: {
        stagePadding: 150,
        items: 3,
        nav: true,

      }

    }
  });
}
if ($('.owl-pro2').length) {
  var heroSlider = $('.owl-pro2');
  var owlCarouselTimeout = 3500;
  $('.owl-pro2').owlCarousel({
    autoplay: false,
    //loop: true,
    //autoplayHoverPause: true,
    smartSpeed: 450,
    rtl: true,
    margin: 0,
    dots: false,
    margin: 15,
    lazyLoad: true,
    responsive: {
      0: {
        items: 1,
        nav: false,
        stagePadding: 30

      },
      400: {
        items: 1,
        nav: false,
        stagePadding: 80
      },

      600: {
        items: 2,
        nav: false,
        stagePadding: 30
      },
      700: {
        margin: 20,
        stagePadding: 70,
        items: 2

      },
      768: {
        items: 3,
        nav: false,

      },
      992: {
        items: 4,
        nav: true,

      },
      1200: {
  
        items: 5,
        nav: true,

      }

    }
  });
}



function initCategoryBar() {
  var $overlay = $(".js-menu-overlay"),
    $naviOverlay = $(".js-navi-overlay"),
    $megaMenuMain = $('.js-mega-menu-main-item'),
    $megaMenuOptionsContainer = $(".js-mega-menu-categories-options"),
    $hoverEffect = $(".js-navi-new-list-category-hover"),
    $headerLinks = $('.js-categories-bar-item'),
    $megaMenuCategory = $('.js-mega-menu-category'),
    $searchBar = $('.js-search'),
    $searchResults = $('.js-search-results');

  var moveHover = function (self) {
    var parent = self
      .parent()
      .parent()
      .parent();

    $hoverEffect
      .css("width", self.width())
      .css(
        "right",
        parent.width() -
        (self.offset().left + self.width()) +
        parent.offset().left
      );
    $hoverEffect.css("transform", "scaleX(1)");
  };

  var removeHover = function () {
    $hoverEffect.css("transform", "scaleX(0)");
  };

  $headerLinks.hover(function () {
      moveHover.call(this, $(this));
    },
    function () {
      removeHover.call(this, $(this));
    });

  $megaMenuMain.on('click', function (e) {
    e.stopPropagation();
  });

  var hoverAction;
  $megaMenuMain.hover(
    function () {
      var $this = $(this);
      hoverAction = setTimeout(function () {
        $this.children(".js-mega-menu-categories-options").css('display', 'flex');
        $naviOverlay.addClass("is-active");
        $searchResults.removeClass("is-active");
        $searchBar.removeClass("is-active");
      }, 200);
    },
    function () {
      hoverAction && clearTimeout(hoverAction);
      $naviOverlay.removeClass("is-active");
      $megaMenuOptionsContainer.hide()
    });

  $megaMenuCategory.hover(
    function () {


      $megaMenuOptionsContainer.find('.js-categories-ad').removeClass('ad-is-active');
      $megaMenuOptionsContainer.find('#categories-ad-' + $(this).data('index')).addClass('ad-is-active');


      $megaMenuOptionsContainer.find('.js-mega-menu-category-options').removeClass('is-active');
      $megaMenuCategory.removeClass('c-navi-new-list__inner-category--hovered');
      $(this).addClass('c-navi-new-list__inner-category--hovered');
      $megaMenuOptionsContainer.find('#categories-' + $(this).data('index')).addClass('is-active');
    },

    function () {}
  );

  $overlay.hover(function () {
    if (!$(this).is(".is-active")) return true;
  });

  $megaMenuCategory.hover(
    function () {


      $megaMenuOptionsContainer.find('.js-categories-ad').removeClass('ad-is-active');
      $megaMenuOptionsContainer.find('#categories-ad-' + $(this).data('index')).addClass('ad-is-active');


      $megaMenuOptionsContainer.find('.js-mega-menu-category-options').removeClass('is-active');
      $megaMenuCategory.removeClass('c-navi-new-list__inner-category--hovered');
      $(this).addClass('c-navi-new-list__inner-category--hovered');
      $megaMenuOptionsContainer.find('#categories-' + $(this).data('index')).addClass('is-active');
    },

    function () {}
  );

};

function initStatic() {
  var $overlay = $(".js-menu-overlay"),
    $naviOverlay = $(".js-navi-overlay"),
    $newCategories = $(".js-navi-new-list-categories"),
    $newCategoryItem = $(".js-navi-new-list-category"),
    $hoverEffect = $(".js-navi-new-list-category-hover"),
    allCategoriesButton = $(".js-navi-new-list__all-links"),
    sentBanners = [];

  this.openCategories = false;
  var mainJs = this;

  $(".js-navi").hover(function () {
    $(this)
      .find("img[data-src]")
      .each(function () {
        $(this)
          .attr("src", $(this).attr("data-src"))
          .removeAttr("data-src");
      });
  });

  var moveHover = function (self) {
    var parent = self
      .parent()
      .parent()
      .parent();

    $hoverEffect
      .css("width", self.width())
      .css(
        "right",
        parent.width() -
        (self.offset().left + self.width()) +
        parent.offset().left
      );
    if ($(this).hasClass("is-fmcg")) {
      $hoverEffect.addClass("is-fmcg");
    } else {
      $hoverEffect.removeClass("is-fmcg");
    }
    $hoverEffect.css("transform", "scaleX(1)");
  };

  var removeHover = function () {
    $hoverEffect.css("transform", "scaleX(0)");
  };

  var handlerHover = function () {
    clearTimeout(this.closeTimer);
    var self = $(this);

    this.timer = setTimeout(function () {
      $("body").click();
      $naviOverlay.addClass("is-active");
      self.addClass("can-show-menu");
      self.siblings(".js-navi-new-list-category").addClass("can-show-menu");
      self.find(".js-navi-new-list-category").addClass("can-show-menu");
      mainJs.openCategories = true;
      var id = self.find(".c-adplacement__item").data("id");

      if (id && sentBanners.indexOf(id) < 0) {
        snt("dkBannerViewed", {
          bannerId: id,
          created_at: Date.now()
        });
        sentBanners.push(id);
      }
      $(".js-search-results").removeClass("is-active");
    }, 200);
    if (self.hasClass("js-navi-new-list-category")) {
      moveHover.call(this, self);
    }
  };
  var handlerOut = function () {
    clearTimeout(this.timer);
    var self = this;

    this.closeTimer = setTimeout(function () {
      if ($(".js-search-results").hasClass("is-active")) return;
      $(self).hasClass("js-navi-new-list-categories") ?
        $naviOverlay.removeClass("is-active") :
        "";
      $(self)
        .find(".js-navi-new-list-category")
        .removeClass("can-show-menu");
      $(self).hasClass("can-show-menu") ?
        $(self).removeClass("can-show-menu") :
        "";
      mainJs.openCategories = false;
    }, 200);
    removeHover();
  };

  // $('.js-navi-list-promotion-item').hover(function () {
  //     moveHover.call(this, $(this));
  // }, removeHover);

  var $w = $(window),
    lastY = $w.scrollTop();

  $(window).scroll(function () {
    var currentPosition = $w.scrollTop();

    if (!mainJs.openCategories) {
      return (lastY = currentPosition);
    }
    if (currentPosition - lastY < -5) {
      var e = jQuery.Event("mouseout");

      $newCategories.trigger(e);

      $newCategoryItem.trigger(e);
    }
    lastY = currentPosition;
  });

  $newCategories.hover(handlerHover, handlerOut);
  $newCategoryItem.hover(handlerHover, handlerOut);
  allCategoriesButton.hover(function (e) {
    e.stopPropagation();
    e.preventDefault();
    $naviOverlay.removeClass("is-active");
  });
  $overlay.hover(function () {
    if (!$(this).is(".is-active")) return true;
  });

  $(".js-expert-article-button").on("click", function (e) {
    var $this = $(this),
      $article = $this.closest(".js-expert-article");

    if ($article.hasClass("is-active")) {
      $article.removeClass("is-active");
    } else {
      $article.addClass("is-active");
    }

    e.preventDefault();

    window.dispatchEvent(new Event("scroll"));
  });

  var $deliveryLabels = $(".js-delivery-label");

  $deliveryLabels.click(function () {
    var $this = $(this);

    if ($this.hasClass("is-read-only")) {
      return;
    }

    $deliveryLabels.removeClass("is-selected");
    $this.addClass("is-selected");
  });

  $deliveryLabels.each(function () {
    var $this = $(this);
    var $radio = $this.find('input[type="radio"]');

    if ($radio.is(":checked")) {
      $this.addClass("is-selected");
    }
  });
};
$(document).ready(function () {
  initCategoryBar();
  initStatic();

});

// $('#date_datepicker').persianDatepicker({
//   showButtonPanel: true,
//   autoSize: true,
//   changeMonth: true,
//   initialValue: true,
//   initialValueType: 'gregorian',
//   altField: '#date',
//   altFormat: 'X',
//   format: 'YYYY MMMM D',
//   observer: true,
//   cellWidth: 40,
//   cellHeight: 38,
//   fontSize: 14,

// });


if ($('.owl-tour').length) {
  var heroSlider = $('.owl-tour');
  var owlCarouselTimeout = 3500;
  $('.owl-tour').owlCarousel({
    autoplay: false,
    //loop: true,
    //autoplayHoverPause: true,
    smartSpeed: 450,
    rtl: true,
    margin: 0,
    dots: true,
    nav:false,
    lazyLoad: true,
    responsive: {
      0: {
        margin: 10,
        items: 1,
        nav: false,
        stagePadding: 70

      },
      400: {
        margin: 10,
        items: 1,
        nav: false,
        stagePadding: 100
      },

      600: {
        margin: 15,
        items: 2,
        nav: false,
        stagePadding: 30
      },
      700: {
        margin: 15,
        margin: 20,
        stagePadding: 70,
        items: 2

      },
      768: {
        margin: 15,
        items: 2,
        stagePadding: 70
      },
      992: {
        items: 3,
        margin: 20

      },
      1200: {
        margin: 20,   
        items: 4

      }

    }
  });
}



function AutoScrollOff() {
  clearTimeout(autoScroll);
  content.removeClass("auto-scrolling-on").mCustomScrollbar("stop");
}

var content=$(".c-navi-new-list__inner-categories"),autoScrollTimer=8000,autoScrollTimerAdjust,autoScroll;
content.mCustomScrollbar({
  scrollButtons:{enable:true},
  autoHideScrollbar:true,
  callbacks:{
      whileScrolling:function(){
          autoScrollTimerAdjust=autoScrollTimer*this.mcs.topPct/100;
      },
      onScroll:function(){
          if($(this).data("mCS").trigger==="internal"){AutoScrollOff();}
      }
  }
});
function AutoScrollOff() {
  clearTimeout(autoScroll);
  content.removeClass("auto-scrolling-on").mCustomScrollbar("stop");
}

var content1=$(".scroll .options"),autoScrollTimer=8000,autoScrollTimerAdjust,autoScroll;
content1.mCustomScrollbar({
  scrollButtons:{enable:true},
  autoHideScrollbar:true,
  callbacks:{
      whileScrolling:function(){
          autoScrollTimerAdjust=autoScrollTimer*this.mcs.topPct/100;
      },
      onScroll:function(){
          if($(this).data("mCS").trigger==="internal"){AutoScrollOff();}
      }
  }
});
  /*----------------------------------------------------*/
  /*  Testimonials Slider
    /*----------------------------------------------------*/
    function testimonials_slider() {
      if ($(".testi_slider").length) {
        $(".testi_slider").owlCarousel({
          loop: true,
          margin: 30,
          items: 2,
          autoplay: 2500,
          smartSpeed: 2500,
          dots: true,
          responsiveClass: true,
          responsive: {
            0: {
              items: 1
            },
            991: {
              items: 2
            }
          }
        });
      }
    }
    testimonials_slider();



      var swiper = new Swiper(".mySwiper", {
        spaceBetween: 10,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
      });
      var swiper2 = new Swiper(".mySwiper2", {
        spaceBetween: 10,
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        thumbs: {
          swiper: swiper,
        },
      });



      $('.owl-similar').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        rtl:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:3
            },
            1000:{
                items:4
            }
        }
    })
      $('.owl-inner-tour-cox').owlCarousel({
        loop:true,
        margin:10,
        nav:false,
        rtl:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    })
  // PRICE RANGE
  let priceRanges = document.querySelectorAll('.js-price-range');

  priceRanges.forEach(el => {
    let downPriceInput = el.closest('.filter-price').querySelector('.js-price-down'),
    upPriceInput = el.closest('.filter-price').querySelector('.js-price-up'),
    inputs = [downPriceInput, upPriceInput];
  
  
    //get maxPrice for slider price
    const maxPrice = +upPriceInput.getAttribute('data-max');
    upPriceInput.value = maxPrice.toLocaleString() + ' p.';
  
    //Init price range slider
    noUiSlider.create(el, {
      range: {
        'min': 0,
        'max': maxPrice },
  
      behaviour: 'drag',
      connect: true,
      start: [0, maxPrice],
      step: 1 });
  
  
    //Update value after scroll pointer in slider
    el.noUiSlider.on('update', values => {
      let [downPrice, upPrice] = values;
  
      downPrice = Number(downPrice).toLocaleString() + ' р.';
      upPrice = Number(upPrice).toLocaleString() + ' р.';
  
      downPriceInput.value = downPrice;
      upPriceInput.value = upPrice;
    });
  
    //Change slider value after inputs change
    inputs.forEach(function (input, handle) {
      input.addEventListener('change', function () {
        let value = this.value;
        value = value.replace(/\s+/g, '');
        value = parseInt(value);
  
        el.noUiSlider.setHandle(handle, value);
      });
    });
  
  });
  
  //clear sliders value
  
  // let clearBtn = document.querySelector('.js-clear-sliders');
  
  // clearBtn.addEventListener('click', e => {
  //   let filterPrices = document.querySelectorAll('.filter-price');
  
  //   filterPrices.forEach(el => {
  //     let priceRange = el.querySelector('.js-price-range'),
  //     priceRangeInputs = el.querySelectorAll('.filter-price__flex-row input');
  
  //     priceRangeInputs.forEach(function (input, handle) {
  //       let maxPrice = handle ? input.getAttribute('data-max') : 0;
  
  //       priceRange.noUiSlider.setHandle(handle, maxPrice);
  //     });
  //   });
  // });

    // $(".skillbar-bar").each(function () {
    //   $(this).animate(
    //     {
    //       width: $(this).parent().attr("data-percent")
    //     },
    //     "fast"
    //   );
    // });
    

    // document.querySelector(".skillbar ").each(function () {
    //   document.querySelector('.skillbar-bar').animate(
    //     {
    //       width: document.querySelector(".skillbar").attr("data-percent")
    //     },
    //     "fast"
    //   );
    // });
  